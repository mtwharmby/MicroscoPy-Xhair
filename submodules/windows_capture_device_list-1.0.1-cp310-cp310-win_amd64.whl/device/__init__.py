from .device import getDeviceList 
